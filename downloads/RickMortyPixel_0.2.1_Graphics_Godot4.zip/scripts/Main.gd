extends Node2D

var player_pos := Vector2(300, 320)
var speed := 230.0
var health := 100
var energy := 100.0
var crystals := 5
var portal := Vector2(800, 280)
var enemy_pos := Vector2(610, 330)
var enemy_hp := 60
var world := 0
var quest := 0
var message := "Рик: Морти, почини портал. И НЕ ТРОГАЙ зеленую жижу."
var message_time := 6.0
var hit_flash := 0.0
var portal_phase := 0.0
var stars: Array[Vector2] = []
var dust: Array[Vector2] = []
var touch := {"left":false,"right":false,"up":false,"down":false,"attack":false}

func _ready():
    randomize()
    for i in range(90):
        stars.append(Vector2(randf_range(0, 960), randf_range(85, 540)))
    for i in range(28):
        dust.append(Vector2(randf_range(0, 960), randf_range(100, 520)))
    queue_redraw()

func _process(delta):
    portal_phase += delta
    hit_flash = max(0.0, hit_flash - delta)
    var dir := Vector2.ZERO
    if Input.is_action_pressed("move_left") or touch.left: dir.x -= 1
    if Input.is_action_pressed("move_right") or touch.right: dir.x += 1
    if Input.is_action_pressed("move_up") or touch.up: dir.y -= 1
    if Input.is_action_pressed("move_down") or touch.down: dir.y += 1
    if dir.length() > 0:
        player_pos += dir.normalized() * speed * delta
    player_pos.x = clamp(player_pos.x, 45.0, 915.0)
    player_pos.y = clamp(player_pos.y, 120.0, 450.0)

    if world == 0 and player_pos.distance_to(portal) < 70:
        world = 1
        player_pos = Vector2(180, 330)
        quest = 1
        message = "Портал сработал! Планета Глюк-7. Найди микросхему."
        message_time = 5.0
    if world == 1 and player_pos.distance_to(Vector2(260, 230)) < 55 and quest == 1:
        quest = 2
        crystals += 10
        message = "Микросхема найдена! Теперь победи мутанта."
        message_time = 4.0
    if world == 1 and player_pos.distance_to(enemy_pos) < 90 and (Input.is_action_just_pressed("attack") or touch.attack):
        if energy >= 10.0 and enemy_hp > 0:
            energy -= 10.0
            enemy_hp -= 20
            hit_flash = 0.12
            message = "Рик: Получай, межпространственная жаба!"
            message_time = 2.0
            if enemy_hp <= 0:
                quest = 3
                crystals += 25
                message = "Мутант повержен! Задание выполнено."
                message_time = 4.0
    energy = min(100.0, energy + 20.0 * delta)
    message_time = max(0.0, message_time - delta)
    queue_redraw()

func _input(event):
    if event is InputEventScreenTouch:
        var p := event.position
        var down := event.pressed
        if Rect2(25, 400, 70, 70).has_point(p): touch.left = down
        elif Rect2(105, 400, 70, 70).has_point(p): touch.right = down
        elif Rect2(65, 325, 70, 70).has_point(p): touch.up = down
        elif Rect2(65, 475, 70, 55).has_point(p): touch.down = down
        elif Rect2(830, 385, 95, 95).has_point(p): touch.attack = down

func _draw():
    if world == 0:
        draw_garage()
    else:
        draw_planet()
    draw_player(player_pos)
    draw_hud()
    draw_controls()
    if hit_flash > 0.0:
        draw_rect(Rect2(0, 0, 960, 540), Color(1, 0.15, 0.12, hit_flash * 0.35))

func draw_garage():
    draw_rect(Rect2(0, 0, 960, 540), Color("#0b111a"))
    draw_rect(Rect2(0, 82, 960, 458), Color("#302a29"))
    # ceiling lamps
    for x in [150, 480, 810]:
        draw_rect(Rect2(x - 55, 96, 110, 10), Color("#20252b"))
        draw_rect(Rect2(x - 34, 104, 68, 5), Color("#d6f5e9"))
        draw_circle(Vector2(x, 116), 22, Color(0.55, 0.9, 0.78, 0.045))
    # wall panels
    for x in range(0, 960, 80):
        draw_line(Vector2(x, 145), Vector2(x, 390), Color("#3d3433"), 2)
    draw_line(Vector2(0, 145), Vector2(960, 145), Color("#554645"), 3)
    # floor tiles
    draw_rect(Rect2(0, 390, 960, 150), Color("#4b3b34"))
    for x in range(0, 1000, 60):
        draw_line(Vector2(x, 390), Vector2(x, 540), Color("#3a302d"), 2)
    for y in range(390, 541, 50):
        draw_line(Vector2(0, y), Vector2(960, y), Color("#3a302d"), 2)
    # workbench
    draw_rect(Rect2(45, 276, 260, 86), Color("#151a21"))
    draw_rect(Rect2(60, 254, 230, 24), Color("#9b7047"))
    draw_rect(Rect2(70, 362, 18, 54), Color("#1b1d21"))
    draw_rect(Rect2(275, 362, 18, 54), Color("#1b1d21"))
    draw_string(ThemeDB.fallback_font, Vector2(78, 312), "ЛАБОРАТОРИЯ", HORIZONTAL_ALIGNMENT_LEFT, -1, 19, Color("#9bd8ef"))
    # bottles and tools
    for x in [82, 118, 154, 190, 226]:
        draw_rect(Rect2(x, 230, 16, 24), Color("#263b4b"))
        draw_rect(Rect2(x + 3, 220, 10, 12), Color("#75d8b2"))
    draw_line(Vector2(240, 220), Vector2(270, 190), Color("#d1a66e"), 5)
    # portal glow and rings
    var pulse := 1.0 + sin(portal_phase * 3.0) * 0.05
    for r in [86.0, 75.0, 64.0]:
        draw_circle(portal, r * pulse, Color(0.15, 1.0, 0.55, 0.025))
    draw_circle(portal, 60, Color("#123b32"))
    draw_arc(portal, 60, 0, TAU, 64, Color("#5cff9c"), 7)
    draw_arc(portal, 48, -portal_phase, TAU - portal_phase, 64, Color("#b8ffd3"), 3)
    draw_circle(portal, 39, Color("#061521"))
    draw_arc(portal, 34, portal_phase * 1.4, TAU, 48, Color("#42ff91"), 5)
    draw_string(ThemeDB.fallback_font, portal + Vector2(-43, 90), "ПОРТАЛ", HORIZONTAL_ALIGNMENT_LEFT, -1, 17, Color("#d8ffe9"))
    draw_title("РИК И МОРТИ  //  ГАРАЖ")

func draw_planet():
    # layered sky
    draw_rect(Rect2(0, 0, 960, 540), Color("#100f24"))
    draw_rect(Rect2(0, 82, 960, 458), Color("#2a2450"))
    for s in stars:
        var twinkle := 0.55 + 0.35 * sin(portal_phase * 2.0 + s.x)
        draw_circle(s, 1.5, Color(0.75, 0.92, 1.0, twinkle))
    # distant hills
    draw_colored_polygon(PackedVector2Array([Vector2(0,390),Vector2(150,300),Vector2(300,380),Vector2(470,290),Vector2(650,380),Vector2(810,300),Vector2(960,365),Vector2(960,540),Vector2(0,540)]), Color("#211e3c"))
    draw_colored_polygon(PackedVector2Array([Vector2(0,440),Vector2(180,350),Vector2(360,420),Vector2(540,330),Vector2(730,425),Vector2(900,350),Vector2(960,390),Vector2(960,540),Vector2(0,540)]), Color("#344255"))
    # ground glow strips
    for y in [405, 450, 500]:
        draw_line(Vector2(0, y), Vector2(960, y), Color(0.35, 0.8, 0.85, 0.06), 2)
    # moon
    draw_circle(Vector2(770, 160), 74, Color("#b85e52"))
    draw_circle(Vector2(750, 145), 55, Color("#d57b58"))
    draw_arc(Vector2(770,160), 95, 0, TAU, 64, Color("#efc35d"), 6)
    # crystals
    for p in [Vector2(260,230), Vector2(150,420), Vector2(850,390)]:
        draw_crystal(p)
    draw_title("ПЛАНЕТА ГЛЮК-7  //  ЗОНА 01")
    # mutant
    if enemy_hp > 0:
        draw_enemy(enemy_pos)
    else:
        draw_string(ThemeDB.fallback_font, Vector2(520, 300), "МУТАНТ ПОВЕРЖЕН", HORIZONTAL_ALIGNMENT_LEFT, -1, 20, Color("#a8ffb0"))

func draw_crystal(p: Vector2):
    var glow := 0.06 + 0.03 * sin(portal_phase * 3.0 + p.x)
    draw_circle(p, 38, Color(0.2, 0.85, 1.0, glow))
    draw_colored_polygon(PackedVector2Array([p + Vector2(0,-30), p + Vector2(17,-7), p + Vector2(11,25), p + Vector2(-10,34), p + Vector2(-19,-4)]), Color("#5de4ff"))
    draw_colored_polygon(PackedVector2Array([p + Vector2(0,-24), p + Vector2(6,-5), p + Vector2(2,22), p + Vector2(-8,10)]), Color("#d8fbff"))
    draw_line(p + Vector2(-18,-3), p + Vector2(9,-18), Color("#b8f5ff"), 2)

func draw_enemy(p: Vector2):
    draw_circle(p + Vector2(0, 6), 43, Color(0.1, 0.9, 0.65, 0.08))
    draw_circle(p, 34, Color("#739b48"))
    draw_circle(p + Vector2(-13,-7), 8, Color("#f5fbf2"))
    draw_circle(p + Vector2(13,-7), 8, Color("#f5fbf2"))
    draw_circle(p + Vector2(-13,-7), 3, Color("#182019"))
    draw_circle(p + Vector2(13,-7), 3, Color("#182019"))
    draw_arc(p + Vector2(0,8), 13, 0, PI, 20, Color("#20241c"), 4)
    draw_rect(Rect2(p + Vector2(-42,-56), Vector2(84, 9)), Color("#241822"))
    draw_rect(Rect2(p + Vector2(-42,-56), Vector2(84.0 * enemy_hp / 60.0, 9)), Color("#ff5865"))
    draw_string(ThemeDB.fallback_font, p + Vector2(-35, 55), "МУТАНТ", HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color("#e7ffdd"))

func draw_player(p: Vector2):
    # shadow
    draw_ellipse(p + Vector2(0, 64), Vector2(24, 7), Color(0,0,0,0.28))
    # legs
    draw_rect(Rect2(p + Vector2(-17, 40), Vector2(11, 24)), Color("#302825"))
    draw_rect(Rect2(p + Vector2(6, 40), Vector2(11, 24)), Color("#302825"))
    # coat/body
    draw_rect(Rect2(p + Vector2(-18, -2), Vector2(36, 47)), Color("#f0f1ec"))
    draw_rect(Rect2(p + Vector2(-14, 4), Vector2(28, 34)), Color("#b7c6c8"))
    draw_line(p + Vector2(0, 5), p + Vector2(0, 38), Color("#718185"), 2)
    # head and hair
    draw_circle(p + Vector2(0,-22), 22, Color("#d8e4e5"))
    var spikes = PackedVector2Array([p+Vector2(-22,-29),p+Vector2(-31,-38),p+Vector2(-19,-37),p+Vector2(-24,-50),p+Vector2(-8,-42),p+Vector2(-4,-56),p+Vector2(5,-42),p+Vector2(18,-52),p+Vector2(17,-39),p+Vector2(30,-43),p+Vector2(21,-29)])
    draw_colored_polygon(spikes, Color("#74a9d2"))
    # eyes
    draw_circle(p + Vector2(-8,-24), 6, Color.WHITE)
    draw_circle(p + Vector2(8,-24), 6, Color.WHITE)
    draw_circle(p + Vector2(-8,-24), 2.5, Color("#15202a"))
    draw_circle(p + Vector2(8,-24), 2.5, Color("#15202a"))
    # mouth
    draw_line(p + Vector2(-7,-12), p + Vector2(7,-12), Color("#713f43"), 2)
    # portal gun
    draw_rect(Rect2(p + Vector2(18, 7), Vector2(25, 10)), Color("#6b727b"))
    draw_rect(Rect2(p + Vector2(35, 3), Vector2(11, 18)), Color("#9aa5ab"))
    draw_circle(p + Vector2(43, 12), 4, Color("#55f0a0"))

func draw_ellipse(center: Vector2, radius: Vector2, color: Color):
    var pts := PackedVector2Array()
    for i in range(32):
        var a := TAU * float(i) / 32.0
        pts.append(center + Vector2(cos(a) * radius.x, sin(a) * radius.y))
    draw_colored_polygon(pts, color)

func draw_title(text: String):
    draw_rect(Rect2(0,0,960,82), Color("#090d14"))
    draw_line(Vector2(0,82), Vector2(960,82), Color("#4bff9b"), 2)
    draw_string(ThemeDB.fallback_font, Vector2(28, 49), text, HORIZONTAL_ALIGNMENT_LEFT, -1, 26, Color("#79f0a6"))
    draw_string(ThemeDB.fallback_font, Vector2(790, 49), "v0.2.1", HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color("#7c8a9a"))

func draw_hud():
    # status card
    draw_panel(Rect2(18, 102, 270, 105))
    draw_string(ThemeDB.fallback_font, Vector2(34, 130), "РИК / МОРТИ", HORIZONTAL_ALIGNMENT_LEFT, -1, 19, Color("#f4f7f8"))
    draw_string(ThemeDB.fallback_font, Vector2(34, 154), "HP", HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color("#aab7c2"))
    draw_bar(Rect2(65, 144, 205, 12), health / 100.0, Color("#5ee27b"))
    draw_string(ThemeDB.fallback_font, Vector2(34, 180), "ENERGY", HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color("#aab7c2"))
    draw_bar(Rect2(85, 170, 185, 12), energy / 100.0, Color("#61b8ff"))
    # crystals
    draw_panel(Rect2(745, 102, 190, 58))
    draw_string(ThemeDB.fallback_font, Vector2(765, 138), "КРИСТАЛЛЫ  %02d" % crystals, HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color("#8deeff"))
    # quest
    draw_panel(Rect2(690, 178, 245, 160))
    draw_string(ThemeDB.fallback_font, Vector2(710, 207), "ЗАДАНИЕ", HORIZONTAL_ALIGNMENT_LEFT, -1, 19, Color("#ffd66b"))
    var q := "Добраться до портала"
    if quest == 1:
        q = "Найти микросхему (1/1)"
    elif quest == 2:
        q = "Победить мутанта"
    elif quest == 3:
        q = "Задание выполнено!"
    draw_string(ThemeDB.fallback_font, Vector2(710, 244), q, HORIZONTAL_ALIGNMENT_LEFT, 205, 17, Color("#f1f4f7"))
    # message
    draw_panel(Rect2(280, 458, 390, 58))
    draw_string(ThemeDB.fallback_font, Vector2(300, 493), message, HORIZONTAL_ALIGNMENT_LEFT, 350, 16, Color("#f1f4f7"))

func draw_panel(rect: Rect2):
    draw_rect(rect, Color("#0b1119e8"))
    draw_rect(Rect2(rect.position + Vector2(1,1), rect.size - Vector2(2,2)), Color("#17212c80"), false, 2)

func draw_bar(rect: Rect2, value: float, fill: Color):
    draw_rect(rect, Color("#26313c"))
    draw_rect(Rect2(rect.position, Vector2(rect.size.x * clamp(value,0.0,1.0), rect.size.y)), fill)
    draw_rect(rect, Color("#8aa0b0"), false, 1)

func draw_controls():
    var buttons = [Rect2(25,400,70,70), Rect2(105,400,70,70), Rect2(65,325,70,70), Rect2(65,475,70,55)]
    for b in buttons:
        draw_rect(b, Color("#071018d9"))
        draw_rect(b, Color("#79dfff"), false, 2)
    draw_string(ThemeDB.fallback_font, Vector2(47,447), "◀", HORIZONTAL_ALIGNMENT_LEFT, -1, 28, Color("#e8faff"))
    draw_string(ThemeDB.fallback_font, Vector2(127,447), "▶", HORIZONTAL_ALIGNMENT_LEFT, -1, 28, Color("#e8faff"))
    draw_string(ThemeDB.fallback_font, Vector2(87,373), "▲", HORIZONTAL_ALIGNMENT_LEFT, -1, 28, Color("#e8faff"))
    draw_string(ThemeDB.fallback_font, Vector2(87,515), "▼", HORIZONTAL_ALIGNMENT_LEFT, -1, 24, Color("#e8faff"))
    var atk := Rect2(830,385,95,95)
    draw_circle(atk.position + atk.size/2, 47, Color("#120b0bdb"))
    draw_circle(atk.position + atk.size/2, 47, Color("#ff8b68"), false, 3)
    draw_circle(atk.position + atk.size/2, 34, Color("#ff704f1f"))
    draw_string(ThemeDB.fallback_font, Vector2(849,438), "ОГОНЬ", HORIZONTAL_ALIGNMENT_LEFT, -1, 17, Color("#fff0eb"))
