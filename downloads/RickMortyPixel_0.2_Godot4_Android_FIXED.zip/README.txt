Rick & Morty: Pixel Adventures — Godot 4
Версия 0.2 — Android prototype

Добавлено: два мира, портал, квест, микросхема, враг с HP, атака, энергия, кристаллы, задания, touch controls и WASD/Space для ПК.
Открыть в Godot 4 через Import -> project.godot.
