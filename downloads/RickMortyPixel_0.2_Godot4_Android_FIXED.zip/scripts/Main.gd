extends Node2D

var player_pos := Vector2(300, 320)
var speed := 230.0
var health := 100
var energy := 100.0
var crystals := 5
var portal := Vector2(800, 280)
var enemy_pos := Vector2(610, 330)
var enemy_hp := 60
var world := 0
var quest := 0
var message := "Рик: Морти, почини портал. И НЕ ТРОГАЙ зелёную жижу."
var message_time := 6.0
var touch := {"left":false,"right":false,"up":false,"down":false,"attack":false}

func _ready(): queue_redraw()

func _process(delta):
    var dir := Vector2.ZERO
    if Input.is_action_pressed("move_left") or touch.left: dir.x -= 1
    if Input.is_action_pressed("move_right") or touch.right: dir.x += 1
    if Input.is_action_pressed("move_up") or touch.up: dir.y -= 1
    if Input.is_action_pressed("move_down") or touch.down: dir.y += 1
    if dir.length() > 0: player_pos += dir.normalized() * speed * delta
    player_pos.x = clamp(player_pos.x, 45.0, 915.0)
    player_pos.y = clamp(player_pos.y, 120.0, 450.0)
    if world == 0 and player_pos.distance_to(portal) < 70:
        world = 1; player_pos = Vector2(180,330); quest = 1
        message = "Портал сработал! Планета Глюк-7. Найди микросхему."; message_time = 5
    if world == 1 and player_pos.distance_to(Vector2(260,230)) < 55 and quest == 1:
        quest = 2; crystals += 10
        message = "Микросхема найдена! Теперь победи мутанта."; message_time = 4
    if world == 1 and player_pos.distance_to(enemy_pos) < 90 and (Input.is_action_just_pressed("attack") or touch.attack):
        if energy >= 10 and enemy_hp > 0:
            energy -= 10; enemy_hp -= 20
            message = "Рик: Получай, межпространственная жаба!"; message_time = 2
            if enemy_hp <= 0:
                quest = 3; crystals += 25
                message = "Мутант побеждён! Задание выполнено."; message_time = 4
    energy = min(100.0, energy + 20.0 * delta)
    message_time = max(0.0, message_time - delta)
    queue_redraw()

func _input(event):
    if event is InputEventScreenTouch:
        var p = event.position; var down = event.pressed
        if Rect2(25,400,70,70).has_point(p): touch.left = down
        elif Rect2(105,400,70,70).has_point(p): touch.right = down
        elif Rect2(65,325,70,70).has_point(p): touch.up = down
        elif Rect2(65,475,70,55).has_point(p): touch.down = down
        elif Rect2(830,385,95,95).has_point(p): touch.attack = down

func _draw():
    if world == 0: draw_garage()
    else: draw_planet()
    draw_player(player_pos); draw_hud(); draw_controls()

func draw_garage():
    draw_rect(Rect2(0,0,960,540),Color("#171b24")); draw_rect(Rect2(0,90,960,450),Color("#47382d")); draw_rect(Rect2(0,390,960,150),Color("#604a37"))
    for x in range(0,960,48): draw_line(Vector2(x,390),Vector2(x,540),Color("#49392d"),2)
    draw_string(ThemeDB.fallback_font,Vector2(30,48),"РИК И МОРТИ — ГАРАЖ",HORIZONTAL_ALIGNMENT_LEFT,-1,28,Color("#75e34b"))
    draw_circle(portal,65,Color("#164e3c")); draw_circle(portal,54,Color("#39e875")); draw_circle(portal,43,Color("#071b2b")); draw_circle(portal,30,Color("#75ff9a"))
    draw_string(ThemeDB.fallback_font,portal+Vector2(-45,90),"ПОРТАЛ",HORIZONTAL_ALIGNMENT_LEFT,-1,18,Color.WHITE)
    draw_rect(Rect2(70,270,190,90),Color("#292d35")); draw_rect(Rect2(90,250,150,25),Color("#8b6a43")); draw_string(ThemeDB.fallback_font,Vector2(95,315),"ГАДЖЕТЫ РИКА",HORIZONTAL_ALIGNMENT_LEFT,-1,17,Color("#b7d6e5"))

func draw_planet():
    draw_rect(Rect2(0,0,960,540),Color("#241c38")); draw_rect(Rect2(0,90,960,450),Color("#5a4057")); draw_circle(Vector2(760,160),75,Color("#d17c45")); draw_arc(Vector2(760,160),95,0,TAU,64,Color("#e9bf5b"),7)
    for p in [Vector2(110,410),Vector2(350,430),Vector2(700,420),Vector2(900,390)]: draw_circle(p,45,Color("#384f4a"))
    var c=Vector2(260,230); draw_colored_polygon(PackedVector2Array([c+Vector2(0,-28),c+Vector2(20,0),c+Vector2(0,28),c-Vector2(20,0)]),Color("#79e8ff"))
    draw_string(ThemeDB.fallback_font,Vector2(30,48),"ПЛАНЕТА ГЛЮК-7",HORIZONTAL_ALIGNMENT_LEFT,-1,28,Color("#75e34b"))
    if enemy_hp > 0:
        draw_circle(enemy_pos,34,Color("#6e933f")); draw_circle(enemy_pos+Vector2(-12,-7),7,Color.WHITE); draw_circle(enemy_pos+Vector2(12,-7),7,Color.WHITE)
        draw_circle(enemy_pos+Vector2(-12,-7),3,Color.BLACK); draw_circle(enemy_pos+Vector2(12,-7),3,Color.BLACK)
        draw_rect(Rect2(enemy_pos+Vector2(-40,-55),Vector2(80,8)),Color("#411f2b")); draw_rect(Rect2(enemy_pos+Vector2(-40,-55),Vector2(80*enemy_hp/60.0,8)),Color("#e04b55"))
    else: draw_string(ThemeDB.fallback_font,Vector2(520,300),"МУТАНТ ПОВЕРЖЕН",HORIZONTAL_ALIGNMENT_LEFT,-1,20,Color("#9cff9c"))

func draw_player(p):
    draw_rect(Rect2(p+Vector2(-17,-2),Vector2(34,45)),Color("#f0f0f0")); draw_rect(Rect2(p+Vector2(-20,-40),Vector2(40,36)),Color("#b9d7e9")); draw_rect(Rect2(p+Vector2(-24,-45),Vector2(48,9)),Color("#6fa6d2")); draw_rect(Rect2(p+Vector2(-17,43),Vector2(11,20)),Color("#382c27")); draw_rect(Rect2(p+Vector2(6,43),Vector2(11,20)),Color("#382c27")); draw_circle(p+Vector2(-10,-25),5,Color.WHITE); draw_circle(p+Vector2(10,-25),5,Color.WHITE)

func draw_hud():
    draw_rect(Rect2(20,105,250,95),Color("#10151dcc")); draw_string(ThemeDB.fallback_font,Vector2(35,130),"Рик / Морти",HORIZONTAL_ALIGNMENT_LEFT,-1,20,Color.WHITE)
    draw_string(ThemeDB.fallback_font,Vector2(35,154),"HP",HORIZONTAL_ALIGNMENT_LEFT,-1,16,Color.WHITE); draw_rect(Rect2(65,143,180,13),Color("#51202a")); draw_rect(Rect2(65,143,180*health/100.0,13),Color("#5be05b"))
    draw_string(ThemeDB.fallback_font,Vector2(35,180),"Энергия",HORIZONTAL_ALIGNMENT_LEFT,-1,16,Color.WHITE); draw_rect(Rect2(95,169,150,13),Color("#202d55")); draw_rect(Rect2(95,169,150*energy/100.0,13),Color("#59aaff"))
    draw_string(ThemeDB.fallback_font,Vector2(730,125),"КРИСТАЛЛЫ: %d" % crystals,HORIZONTAL_ALIGNMENT_LEFT,-1,20,Color("#8deeff"))
    draw_rect(Rect2(280,460,390,55),Color("#0d1119dd")); draw_string(ThemeDB.fallback_font,Vector2(300,493),message,HORIZONTAL_ALIGNMENT_LEFT,350,17,Color.WHITE)
    draw_rect(Rect2(700,205,235,145),Color("#10151ddd")); draw_string(ThemeDB.fallback_font,Vector2(720,235),"ЗАДАНИЕ",HORIZONTAL_ALIGNMENT_LEFT,-1,20,Color("#ffd84d"))
    var q = "Добраться до портала"
    if quest == 1:
        q = "Найти микросхему (1/1)"
    elif quest == 2:
        q = "Победить мутанта"
    elif quest == 3:
        q = "Задание выполнено!"
    draw_string(ThemeDB.fallback_font,Vector2(720,270),q,HORIZONTAL_ALIGNMENT_LEFT,195,17,Color.WHITE)

func draw_controls():
    for b in [Rect2(25,400,70,70),Rect2(105,400,70,70),Rect2(65,325,70,70),Rect2(65,475,70,55)]: draw_rect(b,Color("#00000099")); draw_rect(b,Color("#7be4ff"),false,3)
    draw_string(ThemeDB.fallback_font,Vector2(47,447),"◀",HORIZONTAL_ALIGNMENT_LEFT,-1,28,Color.WHITE); draw_string(ThemeDB.fallback_font,Vector2(127,447),"▶",HORIZONTAL_ALIGNMENT_LEFT,-1,28,Color.WHITE); draw_string(ThemeDB.fallback_font,Vector2(87,373),"▲",HORIZONTAL_ALIGNMENT_LEFT,-1,28,Color.WHITE); draw_string(ThemeDB.fallback_font,Vector2(87,515),"▼",HORIZONTAL_ALIGNMENT_LEFT,-1,24,Color.WHITE)
    var atk=Rect2(830,385,95,95); draw_circle(atk.position+atk.size/2,47,Color("#000000aa")); draw_circle(atk.position+atk.size/2,47,Color("#ff7b52"),false,4); draw_string(ThemeDB.fallback_font,Vector2(850,438),"ОГОНЬ",HORIZONTAL_ALIGNMENT_LEFT,-1,17,Color.WHITE)
